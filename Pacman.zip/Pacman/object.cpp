#include "Object.hpp"

void Object::draw(){
    // SDL_RenderCopy(gRenderer, assets, &srcRect, &moverRect);
}

